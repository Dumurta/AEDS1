#include <stdio.h>
#include <stdlib.h>

void calcularSomaMultiplos(int q)
{
    int soma = 0;
    int contador = 0;
    int numero = 3;

    while (contador < q)
    {
        if (numero % 3 == 0 && numero % 4 != 0)
        {
            printf("%d ", numero);
            soma = soma + numero;
            contador = contador + 1;
        }
        numero = numero + 3;
    }

    printf("\nSoma dos valores: %d\n", soma);
}

void Metodo_06()
{
    IO_id("Metodo_06 v0.0");
    int q = 0;
    printf("Digite a quantidade de termos:\n");
    scanf("%d", &q);

    printf("Valores selecionados: ");
    calcularSomaMultiplos(q);
}

