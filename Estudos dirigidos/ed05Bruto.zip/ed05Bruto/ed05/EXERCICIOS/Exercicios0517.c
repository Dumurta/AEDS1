#include <stdio.h>
#include <stdlib.h>

void calcularSomaInversos(int q)
{
    double soma = 0.0;
    int contador = 0;
    int numero = 4;

    while (contador < q)
    {
        if (numero % 4 == 0 && numero % 5 != 0)
        {
            printf("1/%d ", numero);
            soma = soma + (1.0 / numero);
            contador = contador + 1;
        }
        numero = numero + 4;
    }

    printf("\nSoma dos inversos: %.4lf\n", soma);
}

void Metodo_07()
{
    Io_id("Metodo_07 v0.0");
    int q = 0;
    printf("Digite a quantidade de termos:\n");
    scanf("%d", &q);

    printf("Valores selecionados: ");
    calcularSomaInversos(q);
}

int main()
{
    Metodo_07();
}
