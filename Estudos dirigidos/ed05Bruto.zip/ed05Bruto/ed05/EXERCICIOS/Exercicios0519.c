#include <stdio.h>
#include <stdlib.h>

void calcularSomaQuadrados(int q)
{
    int soma = 0;
    int numero = 25;

    for (int n = 0; n < q; n = n + 1)
    {
        printf("%d ", numero);
        soma = soma + numero;
        numero = numero + 1;
    }

    printf("\nSoma dos quadrados: %d\n", soma);
}

void Metodo_09()
{
    IO_id("Metodo_09 v0.0");
    int q = 0;
    printf("Digite a quantidade de termos:\n");
    scanf("%d", &q);

    printf("Valores selecionados: ");
    calcularSomaQuadrados(q);
}

int main()
{
    Metodo_09();
}
