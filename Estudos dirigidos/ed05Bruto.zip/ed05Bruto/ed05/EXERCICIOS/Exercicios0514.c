#include <stdio.h>
#include <stdlib.h>

void gerarFracoesMultiplos()
{
    int q = 0;
    int x = 3;
    printf("Quantos fracoes com denominadores multiplos de 3 serao feitos?\n");
    scanf("%d", &q);

    for (int n = 0; n < q; n = n + 1)
    {
        printf("{1/%d}", x);
        x = x + 3;
    }
}

int main()
{
    gerarMultiplos();
}