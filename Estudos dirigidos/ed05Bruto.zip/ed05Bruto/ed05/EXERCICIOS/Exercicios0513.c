#include <stdio.h>
#include "io.h"
#include <stdlib.h>
#include <math.h>

void gerarPow()
{
    int q = 0;
    int x = 0;
    printf("Insira um valor para ser decrecido.\n");
    scanf("%d", &q);
    x = pow(4, q);
    for (int n = q; n > 0; n = n - 1)
    {
        printf("%d, ", x);
        x = x / 4;
    }
    printf("\n");
}

int main()
{
    gerarPow();
}