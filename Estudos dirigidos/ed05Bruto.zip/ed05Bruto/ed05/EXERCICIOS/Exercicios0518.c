#include <stdio.h>
#include <stdlib.h>

void calcularSomaAdicao(int q)
{
    int soma = 0;
    int numero = 5;

    for (int n = 0; n < q; n = n + 1)
    {
        printf("%d ", numero);
        soma = soma + numero;
        numero = numero + (n + 1); // soma o valor de (n + 1) ao número
    }

    printf("\nSoma da adição: %d\n", soma);
}

void Metodo_08()
{
    IO_id("Metodo_08 v0.0");
    int q = 0;
    printf("Digite a quantidade de termos:\n");
    scanf("%d", &q);

    printf("Valores selecionados: ");
    calcularSomaAdicao(q);
}

int main()
{
    Metodo_08();
}
