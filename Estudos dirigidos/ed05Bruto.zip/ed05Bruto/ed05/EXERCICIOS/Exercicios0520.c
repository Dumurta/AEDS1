#include <stdio.h>
#include <stdlib.h>

void calcularSomaInversosAdicoes(int q)
{
    double soma = 0.0;
    int numero = 13; // O número começa em 13 para a sequência conforme exemplo.

    for (int n = 0; n < q; n = n + 1)
    {
        printf("1/%d ", numero);
        soma = soma + (1.0 / numero);
        numero = numero - (n + 1); // subtraímos n+1 para que a sequência diminua conforme desejado.
    }

    printf("\nSoma dos inversos: %.4lf\n", soma);
}

void Metodo_10()
{
    IO_id ("Metodo_10");
    int q = 0;
    printf("Digite a quantidade de termos:\n");
    scanf("%d", &q);

    printf("Valores selecionados: ");
    calcularSomaInversosAdicoes(q);
}

int main()
{
    Metodo_10();
}
