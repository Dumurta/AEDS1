#include <stdio.h>
#include <stdlib.h>

void gerarMultiplos()
{
    int q = 0;
    int x = 3;
    printf("Quantos multiplos de 3 serao feitos?\n");
    scanf("%d", &q);

    for (int n = 0; n < q; n = n + 1)
    {
        printf("{%d}", x);
        x = x + 3;
    }
}

int main()
{
    gerarMultiplos();
}