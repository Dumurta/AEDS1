#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void fracoesPow()
{
    int q = 0;
    double x = 0.0;
    printf("Insira um valor real para x:\n");
    scanf("%lf", &x);

    printf("Quantidade de termos da sequencia:\n");
    scanf("%d", &q);

    int inteiro = 0;
    double denominador = 0.0;

    for (int n = 0; n < q; n = n + 1)
    {
        printf("{%d, 1/%.2lf --> 1/%.1lf = (%.3lf) },", inteiro, pow(x, denominador), denominador, 1 / denominador);
        denominador = denominador + 2;
        inteiro = inteiro + 2;
    }
}

int main()
{
    fracoesPow();
}