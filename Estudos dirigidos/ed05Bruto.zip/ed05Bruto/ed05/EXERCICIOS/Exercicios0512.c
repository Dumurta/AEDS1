#include <stdio.h>
#include "io.h"
#include <stdlib.h>

void gerarMultiplos3()
{
    int q = 0;
    int x = 15;
    printf("Quantos multiplos de 3 e 5 serao feitos?\n");
    scanf("%d", &q);

    for (int n = 0; n < q; n = n + 1)
    {
        printf("%d,", x);
        x = x + 15;
    }
}

int main()
{
    gerarVals();
}