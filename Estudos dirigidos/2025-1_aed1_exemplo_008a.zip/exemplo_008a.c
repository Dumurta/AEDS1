// 999999_AED1

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <time.h>

/**
  * Metodo01.
  */
void method_01 ( void )
{
 // definir dados
 // abrir para gravar texto (w = write text)
    FILE * arquivo = fopen ( "DADOS_01.TXT", "w" );
    int    x       = 0;
 // identificar
    printf ( "Method_01\n" );
 // acoes
    do
    {
     // ler     dado
     printf  ( "%s", "\nx = " );
     scanf   ( "%i", &x ); getchar ( );
     // mostrar dado
     printf  (          "%i\n", x );
     // gravar  dado
     fprintf ( arquivo, "%i\n", x );
    }
    while ( x != 0 );
 // INDISPENSAVEL fechar ao gravar
    fclose ( arquivo );
 // encerrar
    printf ( "\n%s\n", "Apertar ENTER para continuar." );
    getchar( );
} // fim method_01 ( )

/**
  * Metodo02.
  */
void method_02 ( void )
{
 // definir dados
 // abrir para ler texto (r = read text)
    FILE * arquivo = fopen ( "DADOS_01.TXT", "r" );
    int    x       = 0;
 // identificar
    printf ( "Method_02\n" );
 // acoes
    fscanf( arquivo, "%i", &x );     // ler o primeiro
    while ( ! feof ( arquivo ) )
    {
     // mostrar dado
     printf (          "%i\n",  x );
     fscanf ( arquivo, "%i"  , &x ); // ler o proximo
    } // end while
 // RECOMENDAVEL fechar ao ler
    fclose ( arquivo );
 // encerrar
    printf ( "\n%s\n", "Apertar ENTER para continuar." );
    getchar( );
} // fim method_02 ( )

/**
  * Metodo03.
  */
void method_03 ( void )
{
 // definir dados
 // abrir para acrescentar ao final (a = append text)
    FILE * arquivo = fopen ( "DADOS_02.TXT", "a" );
    int    x       = 0;
 // identificar
    printf ( "Method_03\n" );
 // acoes
    do
    {
     // ler     dado
     printf  ( "%s", "\nx = " );
     scanf   ( "%i", &x ); getchar ( );
     // mostrar dado
     printf  (          "%i\n", x );
     // gravar  dado
     fprintf ( arquivo, "%i\n", x );
    }
    while ( x != 0 );
 // INDISPENSAVEL ao gravar
    fclose ( arquivo );
 // encerrar
    printf ( "\n%s\n", "Apertar ENTER para continuar." );
    getchar( );
} // fim method_03 ( )

/**
  * Metodo04.
  */
void method_04 ( void )
{
 // definir dados
 // abrir para acrescentar 'a copia
    FILE * arquivo1 = fopen ( "NOVO.TXT"    , "w" );
    FILE * arquivo2 = fopen ( "DADOS_02.TXT", "r" );
    int    x        = 0;
 // identificar
    printf ( "Method_04\n" );
 // acoes
 // copiar dados diferentes de zero
    fscanf( arquivo2, "%i", &x );           // ler o primeiro
    while ( ! feof ( arquivo2 ) )
    {
     // testar se valor lido diferente de zero
        if ( x != 0 )
        {
           fprintf ( arquivo1, "%i\n",  x );
        } // end if
        fscanf     ( arquivo2, "%i"  , &x );// ler o proximo
    } // end while
 // acrescentar ao final da copia
    do
    {
     // ler    dado
        printf  ( "%s", "\nx = " );
        scanf   ( "%i", &x ); getchar ( );
     // gravar dado
        fprintf ( arquivo1, "%i\n", x );
    }
    while ( x != 0 );
 // fechar arquivos
    fclose ( arquivo1 ); // RECOMENDAVEL  ao ler
    fclose ( arquivo2 ); // INDISPENSAVEL ao gravar
 // encerrar
    printf ( "\n%s\n", "Apertar ENTER para continuar." );
    getchar( );
} // fim method_04 ( )

/**
  * Metodo05.
  */
void method_05 ( void )
{
 // definir dados
 // abrir para gravar texto
    FILE * arquivo = fopen ( "DADOS_02.TXT", "wt" );
    double x       = 0.0;
 // identificar
    printf ( "Method_05\n" );
 // acoes
    do
    {
     // ler     dado
     printf  ( "%s", "\nx = " );
     scanf   ( "%lf",  &x ); getchar ( );
     // mostrar dado
     printf  (          "%lf\n", x );
     // gravar  dado
     fprintf ( arquivo, "%lf\n", x );
    }
    while ( x != 0.0 );
 // INDISPENSAVEL fechar ao gravar
    fclose ( arquivo );
 // encerrar
    printf ( "\n%s\n", "Apertar ENTER para continuar." );
    getchar( );
} // fim method_05 ( )

/**
  * Metodo06.
  */
void method_06 ( void )
{
 // definir dados
 // abrir para ler texto
    FILE * arquivo = fopen ( "DADOS_02.TXT", "rt" );
    double x       = 0;
 // identificar
    printf ( "Method_06\n" );
 // acoes
    fscanf( arquivo, "%lf", &x );     // ler o primeiro
    while ( ! feof ( arquivo ) )
    {
     // mostrar dado
     printf (          "%lf\n",  x );
     fscanf ( arquivo, "%lf"  , &x ); // ler o proximo
    } // end while
 // RECOMENDAVEL fechar ao ler
    fclose ( arquivo );
 // encerrar
    printf ( "\n%s\n", "Apertar ENTER para continuar." );
    getchar( );
} // fim method_06 ( )

/**
  * Metodo07.
  */
void method_07 ( void )
{
 // definir dados
 // abrir para gravar texto
    FILE * arquivo = fopen ( "DADOS_03.TXT", "w" );
    char   x = '0';
 // identificar
    printf ( "Method_07\n" );
 // acoes
    do
    {
     // ler     dado
     printf  ( "%s", "\nx = " );
     scanf   ( "%c",   &x ); getchar ( );
     // mostrar dado
     printf  (          "%c\n", x );
     // gravar  dado
     fprintf ( arquivo, "%c\n", x );
    }
    while ( x != '0' );
 // INDISPENSAVEL fechar ao gravar
    fclose ( arquivo );
 // encerrar
    printf ( "\n%s\n", "Apertar ENTER para continuar." );
    getchar( );
} // fim method_07 ( )

/**
  * Metodo08.
  */
void method_08 ( void )
{
 // definir dados
 // abrir para ler texto
    FILE * arquivo = fopen ( "DADOS_03.TXT", "r" );
    char   x = '0';
    char   y = '0';
 // identificar
    printf ( "Method_08\n" );
 // acoes
    fscanf ( arquivo, "%c", &x );    // ler o primeiro
    fscanf ( arquivo, "%c", &y );    // limpar '\n'
    while  ( ! feof ( arquivo ) )
    {
     // mostrar dado
     printf (          "%c\n",  x );
     fscanf ( arquivo, "%c"  , &x ); // ler o proximo
     fscanf ( arquivo, "%c"  , &y ); // limpar '\n'
    } // end while
 // RECOMENDAVEL fechar ao ler
    fclose ( arquivo );
 // encerrar
    printf ( "\n%s\n", "Apertar ENTER para continuar." );
    getchar( );
} // fim method_08 ( )

/**
  * Metodo09.
  */
void method_09 ( void )
{
 // definir dados
 // abrir para gravar texto
    FILE * arquivo = fopen ( "DADOS_04.TXT", "w" );
    char   x [80];
 // identificar
    printf ( "Method_09\n" );
 // acoes
    do
    {
     // ler     dado
     printf  ( "%s", "\nx = " );
     scanf   ( "%s",    x ); getchar ( );
     // mostrar dado
     printf  (          "%s\n", x );
     // gravar  dado
     fprintf ( arquivo, "%s\n", x );
    }
    while ( strcmp ( "0", x ) != 0 );
 // INDISPENSAVEL fechar ao gravar
    fclose ( arquivo );
 // encerrar
    printf ( "\n%s\n", "Apertar ENTER para continuar." );
    getchar( );
} // fim method_09 ( )

/**
  * Metodo10.
  */
void method_10 ( void )
{
 // definir dados
 // abrir para ler texto
    FILE * arquivo = fopen ( "DADOS_04.TXT", "r" );
    char   x [80];
 // identificar
    printf ( "Method_10\n" );
 // acoes
    fscanf ( arquivo, "%s", x );     // ler o primeiro
    while  ( ! feof ( arquivo ) )
    {
     // mostrar dado
     printf (          "%s\n",  x );
     fscanf ( arquivo, "%s"  ,  x ); // ler o proximo
    } // end while
 // RECOMENDAVEL fechar ao ler
    fclose ( arquivo );
 // encerrar
    printf ( "\n%s\n", "Apertar ENTER para continuar." );
    getchar( );
} // fim method_10 ( )

/*
*/
void method_11 ( void )
{
 // definir dados
    int n = 0; // quantidade de dados
    int x = 0;
    int y = 0;
    FILE * arquivo = fopen ( "DADOS_05.TXT", "w" );
 // identificar
    printf ( "%s\n", "\nMetodo_11\n" );
 // acoes
    // ler a quantidade de dados
       printf ( "Quantos dados? " );
       scanf  ( "%d", &n );
    // mostrar a quantidade de dados
       printf ( "n = %d\n", n );
    // semear  a aleatoriedade
       srand  ( time ( NULL ) );
    // repetir
       for ( x=1; x<=n; x=x+1 )
       {
        // gerar valor aleatorio
           y = rand ( );
        // mostrar valor gerado
           printf   ( "%3d\t%d\n",  x, y );
        // gravar  valor gerado
           fprintf  ( arquivo, "%d\n", y );
       }        
    // fechar arquivo
       fclose ( arquivo );
 // encerrar
    printf ( "%s\n", "\nApertar ENTER para continuar\n" );
    getchar( );
}

/*
*/
void method_12 ( void )
{
 // definir dados
    int n = 0; // quantidade de dados
    int x = 0;
    int y = 0;
    FILE * arquivo = fopen ( "DADOS_06.TXT", "w" );
 // identificar
    printf ( "%s\n", "\nMetodo_12\n" );
 // acoes
    // ler a quantidade de dados
       printf ( "Quantos dados? " );
       scanf  ( "%d", &n );
    // mostrar a quantidade de dados
       printf ( "n = %d\n", n );
    // semear  a aleatoriedade
       srand  ( time ( NULL ) );
    // repetir
       for ( x=1; x<=n; x=x+1 )
       {
        // gerar valor aleatorio
           y = rand ( ) % 100; // [0:100)  ou [0:99]
        // mostrar valor gerado
           printf   ( "%3d\t%d\n",  x, y );
        // gravar  valor gerado
           fprintf  ( arquivo, "%d\n", y );
       }        
    // fechar arquivo
       fclose ( arquivo );
 // encerrar
    printf ( "%s\n", "\nApertar ENTER para continuar\n" );
    getchar( );
}

/*
*/
void method_13 ( void )
{
 // definir dados
    int n = 0; // quantidade de dados
    int x = 0;
    int y = 0;
    FILE * arquivo = fopen ( "DADOS_07.TXT", "w" );
 // identificar
    printf ( "%s\n", "\nMetodo_13\n" );
 // acoes
    // ler a quantidade de dados
       printf ( "Quantos dados? " );
       scanf  ( "%d", &n );
    // mostrar a quantidade de dados
       printf ( "n = %d\n", n );
    // semear  a aleatoriedade
       srand  ( time ( NULL ) );
    // repetir
       for ( x=1; x<=n; x=x+1 )
       {
        // gerar valor aleatorio
           y = rand ( ) % (100+1);  // [0:100]
        // mostrar valor gerado
           printf   ( "%3d\t%d\n",  x, y );
        // gravar  valor gerado
           fprintf  ( arquivo, "%d\n", y );
       }
    // fechar arquivo
       fclose ( arquivo );
 // encerrar
    printf ( "%s\n", "\nApertar ENTER para continuar\n" );
    getchar( );
}

/*
*/
void method_14 ( void )
{
 // definir dados
    int n = 0; // quantidade de dados
    int x = 0;
    int y = 0;
    FILE * arquivo = fopen ( "DADOS_08.TXT", "w" );
 // identificar
    printf("%s\n", "\nMetodo_14\n");
 // acoes
    // ler a quantidade de dados
       printf ( "Quantos dados? " );
       scanf  ( "%d", &n );
    // mostrar a quantidade de dados
       printf ( "n = %d\n", n );
    // semear  a aleatoriedade
       srand  ( time ( NULL ) );
    // repetir
       for ( x=1; x<=n; x=x+1 )
       {
        // gerar valor aleatorio
           y = 25 + rand ( ) % (75+1-25); // [25:75]
        // mostrar valor gerado
           printf   ( "%3d\t%d\n",  x, y );
        // gravar  valor gerado
           fprintf  ( arquivo, "%d\n", y );
       }
    // fechar arquivo
       fclose ( arquivo );
 // encerrar
    printf ( "%s\n", "\nApertar ENTER para continuar\n" );
    getchar( );
}

/*
*/
void method_15 ( void )
{
 // definir dados
    int n  = 0; // quantidade de dados
    int x  = 0;
    int y  = 0;
    int y1 = 0;
    int y2 = 0;
    FILE * arquivo = fopen ( "DADOS_09.TXT", "w" );
 // identificar
    printf ( "%s\n", "\nMetodo_15\n" );
 // acoes
    // ler a quantidade de dados
       printf ( "Quantos dados? " );
       scanf  ( "%d", &n );
    // mostrar a quantidade de dados
       printf ( "n = %d\n", n );
    // semear  a aleatoriedade
       srand  ( time (NULL) );
    // repetir
       for ( x=1; x<=n; x=x+1 )
       {
        // gerar valor aleatorio
           y1 = rand ( ); y2 = rand ( );
           if ( y2 % 2 != 0 )
              y  = y1 * (-1);
           else
              y  = y1;
        // mostrar valor gerado
           printf   ( "%3d\t%d\n",  x, y );
        // gravar  valor gerado
           fprintf  ( arquivo, "%d\n", y );
       }        
    // fechar arquivo
       fclose ( arquivo );
 // encerrar
    printf ( "%s\n", "\nApertar ENTER para continuar\n" );
    getchar( );
}

/*
*/
void method_16 ( void )
{
 // definir dados
    int n  = 0; // quantidade de dados
    int x  = 0;
    int y  = 0;
    int y1 = 0;
    int y2 = 0;
    FILE * arquivo = fopen ( "DADOS_10.TXT", "w" );
 // identificar
    printf ( "%s\n", "\nMetodo_16\n" );
 // acoes
    // ler a quantidade de dados
       printf ( "Quantos dados? " );
       scanf  ( "%d", &n );
    // mostrar a quantidade de dados
       printf ( "n = %d\n", n );
    // semear  a aleatoriedade
       srand  ( time (NULL) );
    // repetir
       for ( x=1; x<=n; x=x+1 )
       {
        // gerar valor aleatorio
           y1 = rand ( ); y2 = rand ( );
           y  = y1 - y2;
        // mostrar valor gerado
           printf   ( "%3d\t%d\n",  x, y );
        // gravar  valor gerado
           fprintf  ( arquivo, "%d\n", y );
       }        
    // fechar arquivo
       fclose ( arquivo );
 // encerrar
    printf ( "%s\n", "\nApertar ENTER para continuar\n" );
    getchar( );
}

/*
*/
void method_17 ( void )
{
 // definir dados
    int    n  =  0 ; // quantidade de dados
    int    x  =  0 ;
    double y  = 0.0;
    double y1 = 0.0;
    double y2 = 0.0;
    FILE * arquivo = fopen ( "DADOS_11.TXT", "w" );
 // identificar
    printf ( "%s\n", "\nMetodo_17\n" );
 // acoes
    // ler a quantidade de dados
       printf ( "Quantos dados? " );
       scanf  ( "%d", &n );
    // mostrar a quantidade de dados
       printf ( "n = %d\n", n );
    // semear  a aleatoriedade
       srand  ( time (NULL) );
    // repetir
       for ( x=1; x<=n; x=x+1 )
       {
        // gerar valor aleatorio
           y1 = rand ( ); y2 = rand ( );
           y  = y1 / (y2+1);
        // mostrar valor gerado
           printf   ( "%3d\t%lf\n",  x, y );
        // gravar  valor gerado
           fprintf  ( arquivo, "%lf\n", y );
       }        
    // fechar arquivo
       fclose ( arquivo );
 // encerrar
    printf ( "%s\n", "\nApertar ENTER para continuar\n" );
    getchar( );
}

/*
*/
void method_18 ( void )
{
 // definir dados
    int  n =  0 ; // quantidade de dados
    int  x =  0 ;
    int  y =  0 ;
    char c = '0';
    FILE * arquivo = fopen ( "DADOS_12.TXT", "w" );
 // identificar
    printf ( "%s\n", "\nMetodo_18\n" );
 // acoes
    // ler a quantidade de dados
       printf ( "Quantos dados? " );
       scanf  ( "%d", &n );
    // mostrar a quantidade de dados
       printf ( "n = %d\n", n );
    // semear  a aleatoriedade
       srand  ( time (NULL) );
    // repetir
       for ( x=1; x<=n; x=x+1 )
       {
        // gerar valor aleatorio
           y = 65 + rand ( ) % (90+1-65); // [65:90]
           c = (char) y;
        // mostrar valor gerado
           printf   ( "%3d\t%d\t%c\n", x, y, c );
        // gravar  valor gerado
           fprintf  ( arquivo, "%c\n", y );
       }        
    // fechar arquivo
       fclose ( arquivo );
 // encerrar
    printf ( "%s\n", "\nApertar ENTER para continuar\n" );
    getchar( );
}

/*
*/
void method_19 ( void )
{
 // definir dados
    int    n  =  0 ; // quantidade de dados
    int    x  =  0 ;
    double y  = 0.0;
    double y1 = 0.0;
    double y2 = 0.0;
    FILE * arquivo = fopen ( "DADOS_13.TXT", "w" );
 // identificar
    printf ( "%s\n", "\nMetodo_19\n" );
 // acoes
    // ler a quantidade de dados
       printf ( "Quantos dados? " );
       scanf  ( "%d", &n );
    // mostrar a quantidade de dados
       printf ( "n = %d\n", n );
    // gravar  a quantidade de dados
       fprintf( arquivo, "%d\n", n );
    // semear  a aleatoriedade
       srand  ( time (NULL) );
    // repetir
       for ( x=1; x<=n; x=x+1 )
       {
        // gerar valor aleatorio
           y1 = rand ( ); y2 = rand ( );
           y  = y1 / (y2+1);
           y  = y - (int) y;
           y  = (int) (y * 100.0); // [0:99]
        // mostrar valor gerado
           printf   ( "%3d\t%d\n",  x, (int) y );
        // gravar  valor gerado
           fprintf  ( arquivo, "%d\n", (int) y );
       }
    // fechar arquivo
       fclose ( arquivo );
 // encerrar
    printf ( "%s\n", "\nApertar ENTER para continuar\n" );
    getchar( );
}

/*
*/
void method_20 ( void )
{
 // definir dados
    int n  =  0 ; // quantidade de dados
    int x  =  0 ;
    int y  = 0.0;
    FILE * arquivo = fopen ( "DADOS_13.TXT", "r" );
 // identificar
    printf ( "%s\n", "\nMetodo_20\n" );
 // acoes
    // tentar ler a quantidade de dados
       fscanf  ( arquivo, "%d\n", &n );
    // repetir
       x = 1;
    //           limite fisico       limite logico
       while ( ! feof ( arquivo ) && x <= n )
       {
        // tentar ler o proximo valor
           fscanf  ( arquivo, "%d\n", &y );
        // mostrar valor lido
           printf  ( "%3d\t%d\n",   x, y );
        // passar ao proximo
           x = x + 1;
       }        
    // fechar arquivo
       fclose ( arquivo );
 // encerrar
    printf ( "%s\n", "\nApertar ENTER para continuar\n" );
    getchar( );
}

/**
  * Menu.
  */
void menu ( void )
{
  // identificar
     printf  ( "\n999999_AED1\n" );
     printf  ( "\nMenu"          );
     printf  ( "\n 0 - Terminar " );
     printf  ( "\n 1 - Method_01    2 - Method_02" );
     printf  ( "\n 3 - Method_03    4 - Method_04" );
     printf  ( "\n 5 - Method_05    6 - Method_06" );
     printf  ( "\n 7 - Method_07    8 - Method_08" );
     printf  ( "\n 9 - Method_09   10 - Method_10" );
     printf  ( "\n11 - Method_11   12 - Method_12" );
     printf  ( "\n13 - Method_13   14 - Method_14" );
     printf  ( "\n15 - Method_15   16 - Method_16" );
     printf  ( "\n17 - Method_17   18 - Method_18" );
     printf  ( "\n19 - Method_19   20 - Method_20" );
     printf  ( "\n" );
} // end menu ( )

/**
  * Acao principal.
  */
int main ( void )
{
  // definir dados
     int opcao = 0;

  // acoes
     do
     {
       menu ( );
       printf ( "\nQual a opcao? " );
       scanf  ( "%d", &opcao ); getchar ( );
       printf ( "%d\n",  opcao );
       switch ( opcao )
       {
         case  0: /* nao fazer nada */
           break;
         case  1: method_01 ( ); break;  case  2: method_02 ( ); break;
         case  3: method_03 ( ); break;  case  4: method_04 ( ); break;
         case  5: method_05 ( ); break;  case  6: method_06 ( ); break;
         case  7: method_07 ( ); break;  case  8: method_08 ( ); break;
         case  9: method_09 ( ); break;  case 10: method_10 ( ); break;
         case 11: method_11 ( ); break;  case 12: method_12 ( ); break;
         case 13: method_13 ( ); break;  case 14: method_14 ( ); break;
         case 15: method_15 ( ); break;  case 16: method_16 ( ); break;
         case 17: method_17 ( ); break;  case 18: method_18 ( ); break;
         case 19: method_19 ( ); break;  case 20: method_20 ( ); break;
         default:
                  printf ( "ERRO: Opcao invalida.\nApertar ENTER." );
                  getchar( );
          break;
       } // end switch
     }
     while ( opcao != 0 );
  // encerrar
     printf ( "\nApertar ENTER\n\n" ); getchar( );
     return ( 0 );
} // end main ( )

/*
  Testes e observacoes
*/
